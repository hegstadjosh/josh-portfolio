# extract-image

Extracts a specific diagram/figure from a PDF by describing it in natural language.

## Setup

1. **Gemini API key** — add to your shell profile (e.g. `~/.zshrc`):
   ```bash
   export GEMINI_API_KEY=your_key_here
   ```
   Get one at https://aistudio.google.com/apikey

2. **uv** — Python package runner (handles deps automatically):
   ```bash
   brew install uv
   ```

3. **poppler** — provides `pdfimages` and `pdftoppm`:
   ```bash
   brew install poppler
   ```

That's it. No venv or pip install needed — `uv` handles Python dependencies at runtime.
